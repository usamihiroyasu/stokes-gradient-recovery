import AppKit
import Foundation
let W=1400,H=740,fps=6,count=180
let out=CommandLine.arguments[1],pdfdir=CommandLine.arguments[2]
let navy=NSColor(calibratedRed:0.06,green:0.17,blue:0.23,alpha:1),blue=NSColor(calibratedRed:0.10,green:0.33,blue:0.48,alpha:1),orange=NSColor(calibratedRed:0.70,green:0.39,blue:0.10,alpha:1)
let gray=NSColor(calibratedRed:0.42,green:0.51,blue:0.56,alpha:1),grid=NSColor(calibratedRed:0.84,green:0.89,blue:0.91,alpha:1),bg=NSColor(calibratedRed:0.96,green:0.975,blue:0.98,alpha:1),teal=NSColor(calibratedRed:0.03,green:0.49,blue:0.46,alpha:1)
func rect(_ x:Double,_ y:Double,_ w:Double,_ h:Double)->NSRect {NSRect(x:x,y:Double(H)-y-h,width:w,height:h)}
func pt(_ x:Double,_ y:Double)->NSPoint {NSPoint(x:x,y:Double(H)-y)}
func text(_ s:String,_ x:Double,_ y:Double,_ w:Double,_ size:Double=22,_ weight:NSFont.Weight = .regular,_ color:NSColor?=nil){let p=NSMutableParagraphStyle();p.lineBreakMode = .byClipping;(s as NSString).draw(in:rect(x,y,w,size*1.65),withAttributes:[.font:NSFont.systemFont(ofSize:size,weight:weight),.foregroundColor:color ?? navy,.paragraphStyle:p])}
func line(_ x:Double,_ y:Double,_ a:Double,_ b:Double,_ color:NSColor,_ width:Double=1){let p=NSBezierPath();p.move(to:pt(x,y));p.line(to:pt(a,b));p.lineWidth=width;color.setStroke();p.stroke()}
func circle(_ x:Double,_ y:Double,_ r:Double,_ color:NSColor,_ fill:Bool=true){let p=NSBezierPath(ovalIn:rect(x-r,y-r,2*r,2*r));p.lineWidth=2.5;if fill{color.setFill();p.fill()}else{color.setStroke();p.stroke()}}
func card(_ x:Double,_ y:Double,_ w:Double,_ h:Double){NSColor.white.setFill();NSBezierPath(roundedRect:rect(x,y,w,h),xRadius:16,yRadius:16).fill()}
func polygon(_ points:[NSPoint],_ color:NSColor){let p=NSBezierPath();p.move(to:points[0]);for a in points.dropFirst(){p.line(to:a)};p.close();color.setFill();p.fill();gray.withAlphaComponent(0.4).setStroke();p.lineWidth=1;p.stroke()}
func pdf(_ name:String,_ x:Double,_ y:Double,_ w:Double,_ h:Double){let im=NSImage(contentsOfFile:pdfdir+"/"+name+".pdf")!;let s=min(w/im.size.width,h/im.size.height);let iw=im.size.width*s,ih=im.size.height*s;im.draw(in:rect(x+(w-iw)/2,y+(h-ih)/2,iw,ih))}
func d(_ r:Double)->Double {2*r/(1+r*r)}
func slope(_ r:Double)->Double {2*(1-r*r)/pow(1+r*r,2)}
func plot(_ r:Double,_ d:Double)->NSPoint {pt(105+500*r/2.3,545-310*d/1.08)}
let chapters=["01  Geometry","02  At the fold","03  Inner-sheet certificate"],colors=[teal,orange,blue]
try FileManager.default.createDirectory(atPath:out,withIntermediateDirectories:true)
for f in 0..<count {autoreleasepool {
 let stage=f/60,p=Double(f%60)/59.0,c=colors[stage],r=stage==0 ? 0.05+2.20*(0.5-0.5*cos(Double.pi*p)) : stage==1 ? 1.0 : 0.35+0.5*(0.5-0.5*cos(2*Double.pi*p))
 let rep=NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:W,pixelsHigh:H,bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:0,bitsPerPixel:0)!;rep.size=NSSize(width:W,height:H)
 NSGraphicsContext.saveGraphicsState();NSGraphicsContext.current=NSGraphicsContext(bitmapImageRep:rep);bg.setFill();rect(0,0,Double(W),Double(H)).fill()
 text("A geometric fold and a conditional certificate",38,23,1320,36,.semibold);text("Head coordinates to physical Stokes coordinates",40,73,1300,22,.regular,gray)
 for i in 0...2 {let x=35.0+Double(i)*445;card(x,113,430,43);text(chapters[i],x+16,120,405,21,.semibold,i==stage ? colors[i]:gray);if i==stage{line(x+15,155,x+415,155,colors[i],3)}}
 card(35,175,620,495);card(685,175,680,495);text("Degree of linear polarization d",78,191,555,23,.semibold)
 var inner=[plot(0,0)];for i in 0...120{let a=Double(i)/120;inner.append(plot(a,d(a)))};inner.append(plot(1,0));polygon(inner,teal.withAlphaComponent(stage==2 ? 0.16:0.09))
 let one=plot(1,1);let xx=Double(one.x),yy=Double(H)-Double(one.y)
 line(105,yy,605,yy,grid);line(xx,yy,xx,545,grid);line(105,235,105,545,gray,1.5);line(105,545,615,545,gray,1.5)
 for i in 0...2 {let x=105+500*Double(i)/2.3;line(x,545,x,551,gray);text(String(i),x-10,557,32,19,.regular,gray)}
 text("0",74,533,30,19,.regular,gray);text("1",74,yy-12,30,19,.regular,gray);text("Head radius r",400,592,220,21,.regular,gray)
 for side in 0...1 {let path=NSBezierPath();for i in 0...180{let a=side==0 ? Double(i)/180 : 1+1.3*Double(i)/180;let q=plot(a,d(a));if i==0{path.move(to:q)}else{path.line(to:q)}};path.lineWidth=side==0 ? 4:3;if side==1{path.setLineDash([8,6],count:2,phase:0)};(side==0 ? teal:gray).setStroke();path.stroke()}
 text("inner sheet",150,470,210,21,.medium,teal);text("outer sheet",430,366,200,21,.medium,gray);circle(xx,yy,6,orange)
 let a=max(0,r-0.22),b=min(2.3,r+0.22),pa=plot(a,d(r)+slope(r)*(a-r)),pb=plot(b,d(r)+slope(r)*(b-r));line(Double(pa.x),Double(H)-Double(pa.y),Double(pb.x),Double(H)-Double(pb.y),c,3)
 let q=plot(r,d(r));circle(Double(q.x),Double(H)-Double(q.y),8,c);text(String(format:"r = %.2f",r),86,617,480,22,.medium,c)
 if stage==0{text("A folded response",715,200,610,29,.semibold,teal);pdf("mapping",710,258,630,115);pdf("derivative",710,394,630,80);pdf("geometry_legend",715,502,630,138)}
 if stage==1{text("Recover the missing component",715,200,620,28,.semibold,orange);pdf("fold",710,252,630,78);pdf("recovery",710,344,630,122);pdf("recovery_legend",715,485,630,160)}
 if stage==2{text("A conditional stopping bound",715,200,620,29,.semibold,blue);pdf("bound",710,247,630,85);pdf("conditions",715,350,630,95);pdf("bound_legend",715,470,630,174)}
 text("Fixed intensity and polarization direction",40,700,1310,20,.regular,gray)
 NSGraphicsContext.restoreGraphicsState();let data=rep.representation(using:.png,properties:[:])!;try! data.write(to:URL(fileURLWithPath:String(format:"%@/frame_%04d.png",out,f)),options:.atomic)
}}
print("Rendered \(count) frames at \(fps) fps, \(W)x\(H)")
