# Fold geometry and conditional stopping

The animation follows three steps: the reduced Stokes map, radial information recovery at the fold, and the conditional inner-sheet stopping bound. All formulas are typeset from the adjacent LaTeX sources.

On macOS with Swift, LaTeX and FFmpeg installed, run `zsh reproduce.sh`. The script prints the output path. The animation has 180 frames at 6 fps, lasts 30 seconds, and loops at 1400 x 740 pixels.

Symbol definitions appear in the scene where each quantity is introduced. Each of the three scenes is visible for ten seconds.
