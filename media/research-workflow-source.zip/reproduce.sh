#!/bin/zsh
set -euo pipefail
source_dir=${0:A:h}
render_dir=$(mktemp -d "${TMPDIR:-/tmp}/stokes-workflow.XXXXXX")
mkdir "$render_dir/formula"
for card in mapping derivative fold recovery bound conditions geometry_legend recovery_legend bound_legend; do
  pdflatex -interaction=batchmode -halt-on-error -output-directory "$render_dir/formula" "$source_dir/formula/$card.tex" > /dev/null
done
swiftc -module-cache-path "$render_dir/module_cache" "$source_dir/render.swift" -o "$render_dir/render"
"$render_dir/render" "$render_dir/frames" "$render_dir/formula"
ffmpeg -n -hide_banner -loglevel error -framerate 6 -i "$render_dir/frames/frame_%04d.png" -filter_complex 'split[s0][s1];[s0]palettegen=max_colors=192:stats_mode=diff[p];[s1][p]paletteuse=dither=bayer:bayer_scale=3:diff_mode=rectangle' -loop 0 "$render_dir/research-workflow.gif"
printf 'Animation: %s/research-workflow.gif\n' "$render_dir"
